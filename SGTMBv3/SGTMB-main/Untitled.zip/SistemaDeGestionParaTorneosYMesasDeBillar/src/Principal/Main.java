package Principal;

import Modelos.*;
import EstructurasLineales.*;
import EstructurasNoLineales.*;
import Exceptions.*;

public class Main {

	public static void main(String[] args) {

		System.out.println("Sistema de Gestión - Salón de Billar\n");

		// Mesas del salón
		System.out.println("Estado inicial de las mesas:");

		Mesa[] salon = new Mesa[5];

		for (int i = 0; i < salon.length; i++) {
			salon[i] = new Mesa(i + 1);
			System.out.println(salon[i]);
		}

		// Registro de socios frecuentes
		System.out.println("\nRegistro de socios frecuentes:");

		ArbolAVL<String> socios = new ArbolAVL<>();

		try {

			socios.insert("MBR-005 Carlos");
			socios.insert("MBR-002 Ana");
			socios.insert("MBR-008 Luis");

			System.out.println("Socios registrados correctamente.");

			System.out.println("\nBuscando socio Ana:");
			System.out.println(
				socios.search("MBR-002 Ana")
			);

		} catch (ItemDuplicated | ItemNoFound e) {
			System.out.println(e.getMessage());
		}

		// Simulación de una partida
		System.out.println("\nInicio de partida:");

		salon[0].setOcupada(true);
		salon[0].setHoraInicio("14:30");

		System.out.println(salon[0]);

		double total = salon[0].calcularPrecio("16:45");

		System.out.printf(
			"\nTotal a pagar: S/ %.2f%n",
			total
		);

		salon[0].setOcupada(false);
		salon[0].setHoraInicio("-");

		System.out.println("\nMesa liberada:");
		System.out.println(salon[0]);

		// Historial de movimientos económicos
		System.out.println("\nRegistro de transacciones:");

		ListaDobleEnlazada<String> transacciones =
			new ListaDobleEnlazada<>();

		transacciones.insertarAlFinal(
			"Pago Mesa 1 - S/ 27.00"
		);

		transacciones.insertarAlFinal(
			"Consumo de bebidas - S/ 15.00"
		);

		transacciones.insertarAlFinal(
			"Inscripción torneo - S/ 50.00"
		);

		try {

			transacciones.imprimirHaciaAdelante();

			System.out.println(
				"\nCantidad de movimientos: "
				+ transacciones.size()
			);

		} catch (ExceptionIsEmpty e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nSistema finalizado.");
	}
}