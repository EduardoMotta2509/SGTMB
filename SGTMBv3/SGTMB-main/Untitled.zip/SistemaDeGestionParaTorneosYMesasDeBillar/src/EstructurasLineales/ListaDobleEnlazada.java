package EstructurasLineales;

import Exceptions.ExceptionIsEmpty;

public class ListaDobleEnlazada<T extends Comparable<T>> {

	class NodoDoble {
		public T dato;
		public NodoDoble siguiente;
		public NodoDoble anterior;

		public NodoDoble(T dato) {
			this.dato = dato;
			this.siguiente = null;
			this.anterior = null;
		}
	}

	private NodoDoble cabeza;
	private NodoDoble cola;

	public ListaDobleEnlazada() {
		this.cabeza = null;
		this.cola = null;
	}

	public boolean isEmpty() {
		return cabeza == null;
	}

	// INSERTAR AL INICIO
	public void insertarAlInicio(T dato) {
		NodoDoble nuevo = new NodoDoble(dato);

		if (isEmpty()) {
			cabeza = nuevo;
			cola = nuevo;
		} else {
			nuevo.siguiente = cabeza;
			cabeza.anterior = nuevo;
			cabeza = nuevo;
		}
	}

	// INSERTAR AL FINAL
	public void insertarAlFinal(T dato) {
		NodoDoble nuevo = new NodoDoble(dato);

		if (isEmpty()) {
			cabeza = nuevo;
			cola = nuevo;
		} else {
			cola.siguiente = nuevo;
			nuevo.anterior = cola;
			cola = nuevo;
		}
	}

	// BUSCAR ELEMENTO
	public boolean buscar(T elemento) {
		NodoDoble actual = cabeza;

		while (actual != null) {
			if (actual.dato.compareTo(elemento) == 0) {
				return true;
			}
			actual = actual.siguiente;
		}

		return false;
	}

	// CONTAR ELEMENTOS
	public int size() {
		int contador = 0;
		NodoDoble actual = cabeza;

		while (actual != null) {
			contador++;
			actual = actual.siguiente;
		}

		return contador;
	}

	// OBTENER PRIMER ELEMENTO
	public T getPrimero() throws ExceptionIsEmpty {
		if (isEmpty())
			throw new ExceptionIsEmpty("La lista doble está vacía");

		return cabeza.dato;
	}

	// OBTENER ÚLTIMO ELEMENTO
	public T getUltimo() throws ExceptionIsEmpty {
		if (isEmpty())
			throw new ExceptionIsEmpty("La lista doble está vacía");

		return cola.dato;
	}

	// VACIAR LISTA
	public void clear() {
		cabeza = null;
		cola = null;
	}

	// IMPRIMIR HACIA ADELANTE
	public void imprimirHaciaAdelante() throws ExceptionIsEmpty {

		if (isEmpty())
			throw new ExceptionIsEmpty("La lista doble está vacía");

		NodoDoble actual = cabeza;

		System.out.print("INICIO <-> ");

		while (actual != null) {
			System.out.print(actual.dato.toString() + " <-> ");
			actual = actual.siguiente;
		}

		System.out.println("FIN");
	}

	// IMPRIMIR HACIA ATRÁS
	public void imprimirHaciaAtras() throws ExceptionIsEmpty {

		if (isEmpty())
			throw new ExceptionIsEmpty("La lista doble está vacía");

		NodoDoble actual = cola;

		System.out.print("FIN <-> ");

		while (actual != null) {
			System.out.print(actual.dato.toString() + " <-> ");
			actual = actual.anterior;
		}

		System.out.println("INICIO");
	}

	// ELIMINAR NODO
	public void eliminarNodo(T elemento) throws ExceptionIsEmpty {

		if (isEmpty())
			throw new ExceptionIsEmpty("La lista doble está vacía");

		NodoDoble actual = cabeza;

		while (actual != null) {

			if (actual.dato.compareTo(elemento) == 0) {

				// Único nodo
				if (actual == cabeza && actual == cola) {
					cabeza = null;
					cola = null;
				}

				// Cabeza
				else if (actual == cabeza) {
					cabeza = cabeza.siguiente;

					if (cabeza != null)
						cabeza.anterior = null;
				}

				// Cola
				else if (actual == cola) {
					cola = cola.anterior;

					if (cola != null)
						cola.siguiente = null;
				}

				// Nodo intermedio
				else {
					actual.anterior.siguiente = actual.siguiente;
					actual.siguiente.anterior = actual.anterior;
				}

				return;
			}

			actual = actual.siguiente;
		}
	}
}