package Modelos;

// Joaquín Valdivia

public class NodoDoble<T extends Comparable<T>> {

    private T dato;
    private NodoDoble<T> siguiente;
    private NodoDoble<T> anterior;

    public NodoDoble(T dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }

    public T getDato() {
        return dato;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

    public NodoDoble<T> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDoble<T> siguiente) {
        this.siguiente = siguiente;
    }

    public NodoDoble<T> getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDoble<T> anterior) {
        this.anterior = anterior;
    }

    public boolean tieneSiguiente() {
        return siguiente != null;
    }

    public boolean tieneAnterior() {
        return anterior != null;
    }

    public boolean esAislado() {
        return siguiente == null && anterior == null;
    }

    public void desconectar() {
        siguiente = null;
        anterior = null;
    }

    public int compararCon(NodoDoble<T> otro) {
        return dato.compareTo(otro.getDato());
    }

    public boolean esIgual(NodoDoble<T> otro) {
        return dato.compareTo(otro.getDato()) == 0;
    }

    @Override
    public String toString() {
        return dato.toString();
    }
}