package SystemUtilities;

import Modelos.Miembro;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaMiembros {

    private static final String ARCHIVO = "miembros.txt";

    public static void guardarMiembros(List<Miembro> miembros) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO))) {

            for (Miembro m : miembros) {
                bw.write(m.getId() + ";" + m.getNombre());
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error al guardar miembros: " + e.getMessage());
        }
    }

    public static List<Miembro> cargarMiembros() {

        List<Miembro> miembros = new ArrayList<>();

        File archivo = new File(ARCHIVO);

        if (!archivo.exists()) {
            return miembros;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(";");

                if (datos.length == 2) {
                    miembros.add(new Miembro(datos[0], datos[1]));
                }
            }

        } catch (IOException e) {
            System.out.println("Error al cargar miembros: " + e.getMessage());
        }

        return miembros;
    }
}